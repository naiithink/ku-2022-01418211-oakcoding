# ถูก populate/register บัญชีได้

Admin: No
Staff: Yes
User: Yes
is Extra: No