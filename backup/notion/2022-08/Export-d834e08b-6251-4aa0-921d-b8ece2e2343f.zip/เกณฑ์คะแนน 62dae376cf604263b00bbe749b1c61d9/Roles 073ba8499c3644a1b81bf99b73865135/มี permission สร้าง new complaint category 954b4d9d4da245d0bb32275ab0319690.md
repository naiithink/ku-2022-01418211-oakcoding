# มี permission สร้าง new complaint category

Admin: No
Staff: No
User: No
is Extra: Yes