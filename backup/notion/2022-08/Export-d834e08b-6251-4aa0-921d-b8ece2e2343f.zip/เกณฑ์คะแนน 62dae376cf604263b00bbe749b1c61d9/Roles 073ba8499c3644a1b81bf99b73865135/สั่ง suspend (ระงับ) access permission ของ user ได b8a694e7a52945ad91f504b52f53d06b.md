# สั่ง suspend (ระงับ) access permission ของ user ได้

Admin: Yes
Notes: user ที่ถูก suspend permission
- จะไม่มี permission ในการ login เข้าแอป
- มีข้อความแจ้งเตือนการถูก suspend ตอนจะ login
Staff: No
User: No
is Extra: No