# มี permission to access the Admin account

Admin: Yes
Staff: No
User: No
is Extra: No