# สั่ง unsuspend (คืนสิทธิ์) access permission ของ user ได้

Admin: Yes
Staff: No
User: No
is Extra: No