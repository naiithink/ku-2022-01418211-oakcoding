# มี permission ในการสร้าง Staff account

Admin: Yes
Staff: No
User: No
is Extra: No