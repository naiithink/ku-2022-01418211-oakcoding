# 6

Color Tag: Blue
Scope: submit
Tags: OakCoders
ข้อกำหนด: ชื่อ file, directory ต้อง
- สื่อความหมาย
- ตรงบริบทของงาน
ผลกระทบ: - ( ≥ 10 ) ต่อจุด
ผู้แก้ไข: Potsawat Thinkanwatthana
ผู้ได้รับผลกระทบ: TEAM
ระดับความสำคัญ: MUST
เข้าข่าย: No